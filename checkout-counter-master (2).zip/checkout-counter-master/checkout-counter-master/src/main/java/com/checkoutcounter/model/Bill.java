package com.checkoutcounter.model;

import java.util.Iterator;
import java.util.Set;


public class Bill {
    public Bill(){

    }

    public void setTotalCost(double totalCost) {
        this.totalCost = totalCost;
    }

    public void setTotalSaleTax(double totalSaleTax) {
        this.totalSaleTax = totalSaleTax;
    }

    private int id;
    private double totalCost;
    private double totalSaleTax;
    private Set<Purchase> purchases;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getTotalCost() {
        return totalCost;
    }

    public double getTotalSaleTax() {
        return totalSaleTax;
    }

    public Set<Purchase> getPurchases() {
        return purchases;
    }

    public void setPurchases(Set<Purchase> purchases) {
        this.purchases = purchases;
    }



    public Bill(Set<Purchase> purchases) {
        this.purchases=purchases;
        Iterator<Purchase> iterator = this.purchases.iterator();
        while (iterator.hasNext())   {
            Purchase next = iterator.next();
            totalSaleTax=totalSaleTax+ next.getPurchaseSalesTax();
            totalCost=totalCost+next.getPurchaseCost();
        }
        this.purchases = purchases;
    }



}
