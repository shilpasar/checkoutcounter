package com.checkoutcounter;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import com.checkoutcounter.model.Bill;
import com.checkoutcounter.model.Category;
import com.checkoutcounter.model.Product;
import com.checkoutcounter.model.Purchase;

public class CheckoutCounter  {

	public static void main(String[] args) {
    


	    Category categoryA=new Category("A",10.00);
	    Category categoryB=new Category("B",20.00);
	    Category categoryC=new Category("C",0.00);
	    Product productA=new Product("apple",10.00,categoryA);
	    Product productB=new Product("banana",20.00,categoryB);
	    Product productC=new Product("cherry",30.00,categoryC);
	    Set<Purchase> purchases = new HashSet<>();

	    Purchase purchase1 = new Purchase();
	    purchase1.setProduct(productA);
	    purchase1.setQuantity(2.00);
	    purchase1.setPurchaseCost(purchase1.getProduct().getCost()*purchase1.getQuantity());
	    purchase1.setPurchaseSalesTax(purchase1.getProduct().getSalesTax()*purchase1.getQuantity());
	    Purchase purchase2 = new Purchase();
	    purchase2.setProduct(productB);
	    purchase2.setQuantity(3.00);
	    purchase2.setPurchaseCost(purchase2.getProduct().getCost()*purchase2.getQuantity());
	    purchase2.setPurchaseSalesTax(purchase2.getProduct().getSalesTax()*purchase2.getQuantity());
	    purchases.add(purchase1);
	    purchases.add(purchase2);

	    Bill bill = new Bill();
	    bill.setPurchases(purchases);

	    Iterator<Purchase> iterator = bill.getPurchases().iterator();
	    while (iterator.hasNext())   {
	        Purchase next = iterator.next();
	        bill.setTotalSaleTax(bill.getTotalSaleTax()+next.getPurchaseSalesTax());
	        bill.setTotalCost(bill.getTotalCost()+next.getPurchaseCost());
	    }
	    bill.setPurchases(purchases);
	    
	    System.out.println(bill.getTotalCost());
	
	
	}

}
