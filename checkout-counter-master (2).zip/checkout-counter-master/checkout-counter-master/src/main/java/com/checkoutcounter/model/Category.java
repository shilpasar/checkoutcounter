package com.checkoutcounter.model;

public class Category {


    private String name;
    private double salestax;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getSalestax() {
        return salestax;
    }

    public void setSalestax(double salestax) {
        this.salestax = salestax;
    }

    private int id;

    public Category(String name, double salestax) {
        this.name = name;
        this.salestax = salestax;
    }


    public Category(){

    }
}
